
from flask import Flask, render_template, request, redirect, url_for, flash, session

app = Flask(__name__)
app.secret_key = 'your_secret_key'

ADMIN_USERNAME = 'sahithya'
ADMIN_PASSWORD = 'sahithya123'

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/contact', methods=['GET', 'POST'])
def contact():
    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email']
        message = request.form['message']

        with open('messages.txt', 'a') as f:
            f.write(f"{name}|{email}|{message}\n")

        flash(f"Thank you, {name}! Your message has been sent.")
        return redirect(url_for('contact'))

    return render_template('contact.html')

@app.route('/resume')
def resume():
    return render_template('resume.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        if username == ADMIN_USERNAME and password == ADMIN_PASSWORD:
            session['logged_in'] = True
            flash('Logged in successfully.')
            return redirect(url_for('admin'))
        else:
            flash('Invalid credentials. Try again.')

    return render_template('login.html')

@app.route('/admin')
def admin():
    if not session.get('logged_in'):
        flash('Please log in to access the admin panel.')
        return redirect(url_for('login'))

    messages = []
    try:
        with open('messages.txt', 'r') as f:
            for line in f:
                parts = line.strip().split('|')
                if len(parts) == 3:
                    messages.append({
                        'name': parts[0],
                        'email': parts[1],
                        'message': parts[2]
                    })
    except FileNotFoundError:
        pass

    return render_template('admin.html', messages=messages)

@app.route('/logout')
def logout():
    session.pop('logged_in', None)
    flash('You have been logged out.')
    return redirect(url_for('login'))

@app.route('/delete-message', methods=['POST'])
def delete_message():
    if not session.get('logged_in'):
        return redirect(url_for('login'))

    index_to_delete = int(request.form['index'])

    with open('messages.txt', 'r') as f:
        lines = f.readlines()

    if 0 <= index_to_delete < len(lines):
        del lines[index_to_delete]

        with open('messages.txt', 'w') as f:
            f.writelines(lines)

    flash('Message deleted successfully.')
    return redirect(url_for('admin'))

if __name__ == '__main__':
    app.run(debug=True)