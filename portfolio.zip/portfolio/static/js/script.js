
document.getElementById("mode-toggle").onclick = function () {
  document.body.classList.toggle("dark");
  document.body.classList.toggle("light");
};
